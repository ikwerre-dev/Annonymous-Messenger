<!DOCTYPE html>
<html lang="en">
<head>
	<title>Annonymo</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">	
	<link rel="icon" type="image/png" href="http://<?php echo $_SERVER['SERVER_NAME']?>/annonymo/images/icons/favicon.ico"/>
	<link rel="stylesheet" type="text/css" href="http://<?php echo $_SERVER['SERVER_NAME']?>/annonymo/vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="http://<?php echo $_SERVER['SERVER_NAME']?>/annonymo/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="http://<?php echo $_SERVER['SERVER_NAME']?>/annonymo/fonts/iconic/css/material-design-iconic-font.min.css">
	<link rel="stylesheet" type="text/css" href="http://<?php echo $_SERVER['SERVER_NAME']?>/annonymo/vendor/animate/animate.css">	
	<link rel="stylesheet" type="text/css" href="http://<?php echo $_SERVER['SERVER_NAME']?>/annonymo/vendor/css-hamburgers/hamburgers.min.css">
	<link rel="stylesheet" type="text/css" href="http://<?php echo $_SERVER['SERVER_NAME']?>/annonymo/vendor/animsition/css/animsition.min.css">
	<link rel="stylesheet" type="text/css" href="http://<?php echo $_SERVER['SERVER_NAME']?>/annonymo/vendor/select2/select2.min.css">	
	<link rel="stylesheet" type="text/css" href="http://<?php echo $_SERVER['SERVER_NAME']?>/annonymo/vendor/daterangepicker/daterangepicker.css">
	<link rel="stylesheet" type="text/css" href="http://<?php echo $_SERVER['SERVER_NAME']?>/annonymo/css/util.css">
	<link rel="stylesheet" type="text/css" href="http://<?php echo $_SERVER['SERVER_NAME']?>/annonymo/css/main.css">
</head>